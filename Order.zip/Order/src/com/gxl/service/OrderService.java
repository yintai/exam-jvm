package com.gxl.service;


import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.gxl.bean.OrderInfo;
import com.gxl.bean.Result;
import com.gxl.bean.User;
import com.gxl.dao.OrderDAO;

public class OrderService {
	
	/**
	 * ��������
	 */
	public String create(String order){
		JSONObject json =JSONObject.parseObject(order);
		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setId(json.getLong("id"));
		orderInfo.setCreateTime(new Date());
		orderInfo.setAmounts(json.getDouble("amounts"));
		orderInfo.setState(json.getString("state"));
		orderInfo.setTradingType(json.getString("tradingType"));
		orderInfo.setCurrency(json.getString("currency"));
		JSONObject user =json.getJSONObject("userinfo");
		long id = user.getLong("id");
		String username = user.getString("username");
		
		User userinfo = new User(id, username);
		orderInfo.setUserinfo(userinfo);
		
		return OrderDAO.getInstance().create(orderInfo);
	}
	
	/**
	 * ���ݶ���״̬��ȡ�����б�
	 * @return
	 */
	public String findOrderList(String state){
		Result result = new Result();
		List<OrderInfo> list = OrderDAO.getInstance().findOrderList();
		
		for(OrderInfo orderinfo: list){
			if(orderinfo.getState().equals(state)){
				result.getOrderList().add(orderinfo);
			}else if("ȫ��".equals(state)){
				result.getOrderList().add(orderinfo);
			}
		}
		
		return JSONObject.toJSONString(result).toString();
	}
	
}
