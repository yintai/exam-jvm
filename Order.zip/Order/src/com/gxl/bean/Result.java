package com.gxl.bean;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "result")
public class Result {

	/** 
     * ���ؽ�� 
     */  
    private List<OrderInfo> orderList = new ArrayList<OrderInfo>();

	public List<OrderInfo> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderInfo> orderList) {
		this.orderList = orderList;
	}
    
}
