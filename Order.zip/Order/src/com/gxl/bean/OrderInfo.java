package com.gxl.bean;

import java.util.Date;

public class OrderInfo {

	/**
	 * ����id
	 */
	private long id;
	/**
	 * ���״���ʱ��
	 */
	private Date createTime;
	/**
	 * ����:�ɹ� ,ʧ��,������
	 */
	private String state;
	
	/**
	 * ��������  ֧�������˿�
	 */
	private String tradingType;
	
	/**
	 * ���׽�� ��λԪ
	 */
	private double amounts;
	
	/**
	 * ���ױ���
	 */
	private String currency;
	
	
	private User userinfo;


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public Date getCreateTime() {
		return createTime;
	}


	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getTradingType() {
		return tradingType;
	}


	public void setTradingType(String tradingType) {
		this.tradingType = tradingType;
	}


	public double getAmounts() {
		return amounts;
	}


	public void setAmounts(double amounts) {
		this.amounts = amounts;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public User getUserinfo() {
		return userinfo;
	}


	public void setUserinfo(User userinfo) {
		this.userinfo = userinfo;
	}
	
}
