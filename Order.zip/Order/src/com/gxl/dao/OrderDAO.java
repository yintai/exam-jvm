package com.gxl.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.gxl.bean.OrderInfo;
import com.gxl.bean.User;

public class OrderDAO {
	private static OrderDAO orderDAO;
	
	private List<OrderInfo> orderList = new ArrayList<OrderInfo>();
	
	public static OrderDAO getInstance() {
		if(orderDAO == null){
			orderDAO = new OrderDAO();
		}
		
		return orderDAO;
	}
	
	/**
	 * ��������������Ϣ
	 * @param orderInfo
	 */
	public String create(OrderInfo orderInfo) {
		System.out.println(orderInfo.getUserinfo().getUsername()+"�Ķ�����Ϣ�Ѿ�����");
		return JSONObject.toJSONString(orderInfo);
	}


	public List<OrderInfo> findOrderList(){
		init();
		return orderList;
	}

	public void init() {
		// ��ʼ�����ݿ��е��б�����
		List<OrderInfo> orderList = new ArrayList<OrderInfo>();

		OrderInfo orderInfo1 = createOrderInfo("�ɹ�");
		orderList.add(orderInfo1);

		OrderInfo orderInfo2 = createOrderInfo("�ɹ�");
		orderList.add(orderInfo2);

		OrderInfo orderInfo3 = createOrderInfo("�ɹ�");
		orderList.add(orderInfo3);

		OrderInfo orderInfo4 = createOrderInfo("ʧ��");
		orderList.add(orderInfo4);

		OrderInfo orderInfo5 = createOrderInfo("ʧ��");
		orderList.add(orderInfo5);

		OrderDAO.getInstance().setOrderList(orderList);

	}

	/**
	 * ����������Ϣ
	 * 
	 * @return
	 */
	public OrderInfo createOrderInfo(String state) {
		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setState(state);
		orderInfo.setId(System.currentTimeMillis());
		orderInfo.setAmounts(88.56);
		orderInfo.setCreateTime(new Date());
		orderInfo.setCurrency("�����");
		
		if (state.equals("�ɹ�")) {
			orderInfo.setTradingType("֧��");
		} else {
			orderInfo.setTradingType("�˿�");

		}
		orderInfo.setUserinfo(createUser());
		return orderInfo;
	}

	/**
	 * �����û���Ϣ
	 * 
	 * @return
	 */
	private User createUser() {
		long id = System.currentTimeMillis();
		String username = "����";
		return new User(id, username);
	}
	
	public void setOrderList(List<OrderInfo> orderList) {
		this.orderList = orderList;
		System.out.println(orderList.size());
	}

}
