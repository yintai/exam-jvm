package com.gxl.test;

import org.junit.Test;

/**
 *  接口测试类
 * @author xiaolei
 *
 */
public class OrderTest {

	public final String REST_SERVICE_URL = "http://localhost:8080/Order/rest/createOrder/%7B%22amounts%22:88.56,%22createTime%22:1436462416773,%22currency%22:%22%E4%BA%BA%E6%B0%91%E5%B8%81%22,%22id%22:1436462416773,%22state%22:%22%E6%88%90%E5%8A%9F%22,%22tradingType%22:%22%E4%BB%A3%E4%BB%98%E6%AC%BE%22,%22userinfo%22:%7B%22id%22:1436462416773,%22username%22:%22%E5%BC%A0%E4%B8%89%22%7D%7D";

	@Test
	public void createOrder() {
		String str = HttpClientUtils.get(REST_SERVICE_URL);
		System.out.println(str);
	}

	/**
	 * 查询成功的订单
	 */
	@Test
	public void findOrderByState() {
		String str = HttpClientUtils.get("http://localhost:8080/Order/rest/findOrderList/成功");
		System.out.println(str);
	}

	/**
	 * 查询失败的订单
	 */
	@Test
	public void findOrderByState1() {
		String str = HttpClientUtils.get("http://localhost:8080/Order/rest/findOrderList/失败");
		System.out.println(str);
	}
	
	
	/**
	 * 查询全部的订单
	 */
	@Test
	public void findOrderByState2() {
		String str = HttpClientUtils.get("http://localhost:8080/Order/rest/findOrderList/全部");
		System.out.println(str);
	}
}
