package com.gxl.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.gxl.bean.OrderInfo;
import com.gxl.bean.Result;
import com.gxl.service.OrderService;

@Path("/rest")
public class Order {

	private OrderService orderService = new OrderService();
	
	/**
	 * ���������ӿ�
	 */
	@GET
	@Path("/createOrder/{param}")
	@Consumes("application/json;charset=UTF-8")
	@Produces(MediaType.TEXT_PLAIN)
	public String createOrder(@PathParam("param")String orderinfo){
		System.out.println(orderinfo);
		
		return "�������ɳɹ���������ϢΪ��"+orderService.create(orderinfo);
	}
	
	/**
	 * ��ѯ�����б�
	 */
	@GET
	@Path("/findOrderList/{param}")
	@Consumes("application/json;charset=UTF-8")
	@Produces(MediaType.TEXT_PLAIN)
	public String findOrderList(@PathParam("param")String state){
		String str = orderService.findOrderList(state);
		return str;
	}
}
